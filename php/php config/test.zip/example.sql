CREATE TABLE names (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name VARCHAR NOT NULL
);

INSERT INTO names (name) VALUES ('John Doe');
INSERT INTO names (name) VALUES ('Jane Doe');
INSERT INTO names (name) VALUES ('Mary Doe');
INSERT INTO names (name) VALUES ('Some Doe');
